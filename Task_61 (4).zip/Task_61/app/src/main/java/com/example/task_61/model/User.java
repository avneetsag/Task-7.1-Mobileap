package com.example.task_61.model;

public class User {
public static String NOTE_EDIT_EXTRA = "noteEdit";
    private int notes_id;
    private String notes;

    public User(String notes) {
        this.notes = notes;
    }

    public User() {
    }

    public int getNotes_id() {
        return notes_id;
    }

    public void setNotes_id(int notes_id) {
        this.notes_id = notes_id;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }
}
