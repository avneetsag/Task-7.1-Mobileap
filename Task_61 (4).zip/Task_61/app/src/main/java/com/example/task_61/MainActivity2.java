package com.example.task_61;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.task_61.data.DataBaseHelper;
import com.example.task_61.model.User;

public class MainActivity2 extends AppCompatActivity {
      EditText editText;
      Button saveButton;
      DataBaseHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        editText = findViewById(R.id.editText);
        saveButton = findViewById(R.id.savebutton);
        db = new DataBaseHelper(this);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String notes = editText.getText().toString();
                long result = db.insertUser(new User(notes));
                if(result > 0)
                {
                    Toast.makeText(MainActivity2.this, "", Toast.LENGTH_SHORT).show();
                }

                finish();
            }
        });
    }
}