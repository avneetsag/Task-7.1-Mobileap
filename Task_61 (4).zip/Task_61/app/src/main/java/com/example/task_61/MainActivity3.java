package com.example.task_61;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.task_61.data.DataBaseHelper;
import com.example.task_61.model.User;

import java.util.ArrayList;
import java.util.List;

public class MainActivity3 extends AppCompatActivity {
    ListView listView;

    ArrayList<String> userArrayList;
    ArrayAdapter<String> adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        listView = findViewById(R.id.listView);
        userArrayList = new ArrayList<>();
        DataBaseHelper db = new DataBaseHelper(MainActivity3.this);

        List<User> listview = db.fetchAllUsers();
        for(User user :listview)
        {
            userArrayList.add(user.getNotes());
        }

        adapter = new ArrayAdapter<>( this, android.R.layout.simple_list_item_1, userArrayList);
        listView.setAdapter(adapter);

        setOnClickListener();

    }

    public void setOnClickListener()
    {
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l)
            {
                Intent editNoteIntent = new Intent(MainActivity3.this, MainActivity4.class);
                startActivity(editNoteIntent);
            }
        });
    }
}