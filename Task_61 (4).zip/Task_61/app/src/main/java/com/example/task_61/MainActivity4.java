package com.example.task_61;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.task_61.data.DataBaseHelper;
import com.example.task_61.model.User;

public class MainActivity4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        EditText editText2 = findViewById(R.id.editText2);
        Button updateButton = findViewById(R.id.updateButton);
        Button deleteButton = findViewById(R.id.deleteButton);
        DataBaseHelper db = new DataBaseHelper(this);

        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String notes = editText2.getText().toString();
                int updateRow = db.updateNotes(new User(notes));
                if(updateRow > 0)
                {
                    Toast.makeText(MainActivity4.this, "", Toast.LENGTH_SHORT).show();
                }
                finish();
            }
        });

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String notes = editText2.getText().toString();
                int delete = db.deleteNotes(new User(notes));
                if(delete > 0)
                {
                    Toast.makeText(MainActivity4.this, "", Toast.LENGTH_SHORT).show();
                }
                finish();
            }
        });

    }
}