package com.example.task_61;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.task_61.data.DataBaseHelper;

public class MainActivity extends AppCompatActivity {
     DataBaseHelper db;
    Button createbutton, showbutton;
    public void createButton(View view)
    {
        Intent intent = new Intent(this, MainActivity2.class);
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        createbutton = findViewById(R.id.createbutton);
        showbutton = findViewById(R.id.showbutton);

        showbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent showIntent = new Intent(MainActivity.this, MainActivity3.class);
                startActivity(showIntent);
            }
        });
    }
}