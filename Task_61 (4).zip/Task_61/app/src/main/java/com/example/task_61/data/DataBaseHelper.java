package com.example.task_61.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.task_61.model.User;
import com.example.task_61.util.Util;

import java.util.ArrayList;
import java.util.List;

public class DataBaseHelper extends SQLiteOpenHelper {
    public DataBaseHelper(@Nullable Context context) {
        super(context, Util.DATABASE_NAME, null, Util.DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String CREATE_NOTES_TABLE = " CREATE TABLE " + Util.TABLE_NAME + "(" + Util.USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT , " + Util.NOTES + " TEXT) ";
        db.execSQL(CREATE_NOTES_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(" DROP TABLE IF EXISTS " + Util.TABLE_NAME);
        onCreate(db);
    }

    public long insertUser(User user)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(Util.NOTES, user.getNotes());
        long newRowID = db.insert(Util.TABLE_NAME, null, contentValues);
        db.close();
        return newRowID;
    }

    public boolean fetchUser(String notes)
    {
        SQLiteDatabase db =  this.getReadableDatabase();
        Cursor cursor = db.query(Util.TABLE_NAME, new String[]{Util.USER_ID}, Util.NOTES + "=?", new String[] {notes}, null, null, null );
        int numberOfRows = cursor.getCount();
        db.close();

        if (numberOfRows > 0)
            return true;
        else
            return false;
    }

    public List<User> fetchAllUsers (){
        List<User> listview = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String selectAll = " SELECT * FROM " + Util.TABLE_NAME;
        Cursor cursor = db.rawQuery(selectAll, null);

        if (cursor.moveToFirst()) {
            do {
                User user = new User();
                user.setNotes_id(cursor.getInt(0));
                user.setNotes(cursor.getString(1));

                listview.add(user);

            } while (cursor.moveToNext());

        }

        return listview;
    }

    public int updateNotes(User user)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(Util.NOTES, user.getNotes());

        return db.update(Util.TABLE_NAME, contentValues, Util.NOTES + "=?", new String[]{String.valueOf(user.getNotes())});

    }

    public int deleteNotes(User user)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(Util.TABLE_NAME,Util.NOTES + "=?", new String[]{String.valueOf(user.getNotes())});
    }
}
